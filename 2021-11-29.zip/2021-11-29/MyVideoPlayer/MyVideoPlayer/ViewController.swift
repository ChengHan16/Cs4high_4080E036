//
//  ViewController.swift
//  MyVideoPlayer
//
//  Created by guest1 on 11/29/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

