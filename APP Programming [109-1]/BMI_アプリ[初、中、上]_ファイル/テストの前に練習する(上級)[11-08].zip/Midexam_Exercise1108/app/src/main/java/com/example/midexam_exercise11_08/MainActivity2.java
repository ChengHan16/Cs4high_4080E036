package com.example.midexam_exercise11_08;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.os.IResultReceiver;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity2 extends AppCompatActivity {

    DecimalFormat df = new DecimalFormat("##.00");
    private TextView display4;
    private ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        setTitle("BMI_Page2_上級");
        setComponent();

        Bundle bundle = getIntent().getExtras();

        String name = bundle.getString("key1","Default");
        TextView display5 = findViewById(R.id.display5);
        display5.setText(name);


        double  bmi = bundle.getDouble("BMI");
        display4.setText(df.format(bmi));
        getStatus(bmi);



        Button btn_to_page2 = findViewById(R.id.button3);
        btn_to_page2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity2.this,MainActivity.class);
                finish();
            }
        });
    }

    public void setComponent(){
        display4 = findViewById(R.id.display4);
        imageView = findViewById(R.id.imageview);
    }

    public void getStatus(double bmi){
        if (bmi < 18.5){
            imageView.setImageDrawable(getResources().getDrawable(R.drawable.no1));
        }
        else if (18.5 <= bmi && bmi < 24)
            imageView.setImageDrawable(getResources().getDrawable(R.drawable.no2));
        else if (24 <= bmi && bmi < 27)
            imageView.setImageDrawable(getResources().getDrawable(R.drawable.no3));
        else if (27 <= bmi && bmi < 30)
            imageView.setImageDrawable(getResources().getDrawable(R.drawable.no4));
        else if (30 <= bmi && bmi < 35)
            imageView.setImageDrawable(getResources().getDrawable(R.drawable.no5));
        else if (bmi >= 35)
            imageView.setImageDrawable(getResources().getDrawable(R.drawable.no6));
    }
}