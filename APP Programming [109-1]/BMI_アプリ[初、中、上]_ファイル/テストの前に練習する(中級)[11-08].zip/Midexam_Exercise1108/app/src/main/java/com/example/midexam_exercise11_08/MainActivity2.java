package com.example.midexam_exercise11_08;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.os.IResultReceiver;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        setTitle("BMI_Page2_中級");

        Bundle bundle = getIntent().getExtras();

        String BMI = bundle.getString("key1","Default");
        TextView display4 = findViewById(R.id.display4);
        display4.setText(BMI);

        Button btn_to_page2 = findViewById(R.id.button3);
        btn_to_page2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(MainActivity2.this,MainActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}