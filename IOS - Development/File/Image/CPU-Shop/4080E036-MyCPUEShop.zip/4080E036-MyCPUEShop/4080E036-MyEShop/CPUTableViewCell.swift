//
//  CPUTableViewCell.swift
//  4080E036-MyEShop
//
//  Created by guest1 on 2021/10/18.
//

import UIKit

class CPUTableViewCell: UITableViewCell {

    @IBOutlet weak var ballImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var valueLabel: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
